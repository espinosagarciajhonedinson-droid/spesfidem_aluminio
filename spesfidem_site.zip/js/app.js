/**
 * Spesfidem Aluminio - App Logic
 * Handles Client Database (localStorage) and Payment Simulation
 */

// --- Constants ---
const DB_KEY = 'spesfidem_clients';

// --- Client Registration Logic ---
function saveClient(event) {
    event.preventDefault(); // Stop form submission

    // 1. Get Values
    const fullName = document.getElementById('fullName').value;
    const cellphone = document.getElementById('cellphone').value;
    const landline = document.getElementById('landline').value; // Optional
    const address = document.getElementById('address').value;
    const email = document.getElementById('email').value;

    // 2. Create Client Object
    const newClient = {
        id: Date.now(), // Unique ID based on timestamp
        fullName,
        cellphone,
        landline,
        address,
        email,
        date: new Date().toLocaleString()
    };

    // 3. Get Existing DB
    let clients = JSON.parse(localStorage.getItem(DB_KEY)) || [];

    // 4. Add New Client
    clients.push(newClient);

    // 5. Save Back to DB
    localStorage.setItem(DB_KEY, JSON.stringify(clients));

    // 6. Success Feedback
    alert(`¡Gracias ${fullName}! Tus datos han sido registrados.\nTe contactaremos al ${cellphone} pronto.`);

    // Optional: Reset form
    document.getElementById('clientForm').reset();

    console.log('Client saved:', newClient);
}

// --- Payment Simulation ---
function simulatePayment(provider) {
    // Visual feedback
    const confirmPay = confirm(`¿Deseas iniciar el pago seguro con ${provider}?`);

    if (confirmPay) {
        // Find the "Payment UI" container
        // In a real app, this would redirect to Wompi/PayU
        alert(`Conectando con ${provider}...\n\n(SIMULACIÓN: Pago Aprobado)\n\nGracias por confiar en Spesfidem.`);
    }
}

// --- Admin Panel Logic (Runs only on admin.html) ---
function loadAdminData() {
    const tableBody = document.getElementById('clientTableBody');
    if (!tableBody) return; // Not on admin page

    const clients = JSON.parse(localStorage.getItem(DB_KEY)) || [];
    const countElement = document.getElementById('clientCount');

    if (countElement) countElement.textContent = clients.length;

    tableBody.innerHTML = ''; // Clear current

    if (clients.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding: 2rem;">No hay clientes registrados aún.</td></tr>';
        return;
    }

    // Sort by newest first
    clients.sort((a, b) => b.id - a.id);

    clients.forEach(client => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${client.date}</td>
            <td style="font-weight:bold; color:var(--text-dark);">${client.fullName}</td>
            <td>${client.cellphone} <br> <small>${client.landline || ''}</small></td>
            <td>${client.email}</td>
            <td>${client.address}</td>
            <td><span class="status-badge">Nuevo</span></td>
        `;
        tableBody.appendChild(row);
    });
}

// Initialize Admin if needed
document.addEventListener('DOMContentLoaded', loadAdminData);
